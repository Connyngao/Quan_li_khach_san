/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;


import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.phieuthuephong;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;





/**
 *
 * @author user
 */
public class phieuthuephongdao extends khachhangdao{
    
 
  public  int add(phieuthuephong ptp)
  {
      Connection  con= null;
      PreparedStatement sttm = null;
      try {
      
           String sql="insert into phieu_thue_phong(id,sophong,maphieudv) Values(?,?,?)";
           con = ketnoidb.getConnection();
           sttm = con.prepareStatement(sql);
           sttm.setInt(1, ptp.getIdp());
           sttm.setString(2, ptp.getSophongString()); 
           sttm.setString(3, ptp.getMaphieudvString());
            if(sttm.executeUpdate()>0){
                System.out.println("Them thanh cong.");
               
                return 1;
            }
      } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                con.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
     
  }
    public  int edit(phieuthuephong ptp)
  {
      Connection  con= null;
      PreparedStatement sttm = null;
      try {
      
           String sql="update phieu_thue_phong set sophong=? where id=?";
           con = ketnoidb.getConnection();
           sttm = con.prepareStatement(sql);
           sttm.setInt(2, ptp.getIdp());
           sttm.setString(1, ptp.getSophongString()); 
            if(sttm.executeUpdate()>0){
                System.out.println("Them thanh cong.");
               
                return 1;
            }
      } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                con.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
  }
  
     // Lấy toàn bộ thông tin từ CSDL đưa vào List
         public static List<phieuthuephong> getAllptp(){
             List<phieuthuephong> list=new ArrayList<>();
             Connection conn=null;
             Statement sttm=null;
             ResultSet rs=null;
             try {
                 String sSQL="SELECT `id` `sophong`,`maphieudv` FROM `phieu_thue_phong` ORDER BY id DESC";
                 conn=ketnoidb.getConnection();
                 sttm=conn.createStatement();
                 rs=sttm.executeQuery(sSQL);
                 while(rs.next()){
                     phieuthuephong kh=new phieuthuephong();
                     kh.setIdp(rs.getInt(1));
                     kh.setSophongString(rs.getString(2));
                     kh.setMaphieudvString(rs.getString(3));                
                     list.add(kh);
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     rs.close();
                     sttm.close();
                     conn.close();
                 } catch (Exception e) {
                 }
             }
             return list;
}
// thêm phiếu dv vào bảng phiêu thuê phòng 
//
//
//
//
//         
  public  int addptdv(phieuthuephong ptp)
   {
     
    Connection conn=null;
    PreparedStatement sttm=null;
        try {
            String sSQL="UPDATE `phieu_thue_phong` SET maphieudv=? WHERE id=(SELECT max(id) FROM phieu_thue_dv "
                    + "WHERE id=(SELECT MAX(id) FROM phieu_thue_phong WHERE sophong=?))";
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setString(1, ptp.getMaphieudvString());
            sttm.setString(2, ptp.getSophongString());
            if(sttm.executeUpdate()>0){
                System.out.println("sua thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
    }
   
}

    
   
