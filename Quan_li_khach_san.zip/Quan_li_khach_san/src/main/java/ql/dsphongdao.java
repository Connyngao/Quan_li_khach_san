/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.dsphong;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author user
 */
public class dsphongdao {
        SimpleDateFormat fm = new SimpleDateFormat("dd-mm-yyy");
        Scanner sc = new Scanner(System.in);
       
    //thêm phong
     public int add(dsphong phong){
    Connection conn=null;
    PreparedStatement sttm=null;
        try {
            String sSQL="INSERT into `ds_phong` (`sophong`, `loaiphong`, `giaphong`, `tinhtrangphong`,`ghichu`) VALUES (?,?,?,?,?)";
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setString(1,phong.getSophong() );
            sttm.setString(2, phong.getLoaiphong());
            sttm.setInt(3, phong.getGiaphong());
            sttm.setString(4, phong.getTinhtrangphong());
            sttm.setString(5, phong.getGhichu());
            if(sttm.executeUpdate()>0){
                System.out.println("Them thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
    }
    //them phong
        public int edit(dsphong phong){
    Connection conn=null;
    PreparedStatement sttm=null;
        try {
            String sSQL="update `ds_phong` set `loaiphong`=?, `giaphong`=?, `tinhtrangphong`=?,`ghichu`=? where `sophong`=?" ;
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setString(5,phong.getSophong() );
            sttm.setString(1, phong.getLoaiphong());
            sttm.setInt(2, phong.getGiaphong());
            sttm.setString(3, phong.getTinhtrangphong());
            sttm.setString(4, phong.getGhichu());
            if(sttm.executeUpdate()>0){
                System.out.println("sua thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
    }
     public int delete(String sophong){
    Connection conn=null;
    PreparedStatement sttm=null;
        try {
            String sSQL="DELETE FROM `ds_phong` WHERE sophong=?";
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setString(1, sophong);
            
            if(sttm.executeUpdate()>0){
                System.out.println("Xoa thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không xóa thành công
    return -1; 
    }
     // Lấy toàn bộ thông tin từ CSDL đưa vào List
         public  List<dsphong> getAlldsphong(){
               List<dsphong> list=new ArrayList<>();
             Connection conn=null;
             Statement sttm=null;
             ResultSet rs=null;
             try {
                 String sSQL="SELECT `sophong`, `loaiphong`, `giaphong`, `tinhtrangphong`, `ghichu` FROM `ds_phong` ORDER BY giaphong DESC";
                 conn=ketnoidb.getConnection();
                 sttm=conn.createStatement();
                 rs=sttm.executeQuery(sSQL);
                 while(rs.next()){
                     dsphong phong=new dsphong();
                     phong.setSophong(rs.getString(1));
                     phong.setLoaiphong(rs.getString(2));
                     phong.setGiaphong(rs.getInt(3));
                     phong.setTinhtrangphong(rs.getString(4));
                     phong.setGhichu(rs.getString(5));
                     list.add(phong);
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     rs.close();
                     sttm.close();
                     conn.close();
                 } catch (Exception e) {
                 }
             }
             return list;
         }
         // tìm kiếm theo so phong
         public dsphong getBysophong(String sophong){
         Connection conn =null;
         PreparedStatement sttm=null;
         ResultSet rs=null;
         dsphong phong=new dsphong();
             try {
                 String sqlString="SELECT `sophong`,`loaiphong`, `giaphong`, `tinhtrangphong`, `ghichu` FROM `ds_phong` WHERE sophong=?";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sqlString);
                 sttm.setString(1, sophong);
                 rs=sttm.executeQuery();
                 while(rs.next()){                    
                     phong.setSophong(rs.getString(1));
                     phong.setLoaiphong(rs.getString(2));
                     phong.setGiaphong(rs.getInt(3));
                     phong.setTinhtrangphong(rs.getString(4));
                     phong.setGhichu(rs.getString(5));
                     
                     return phong;
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     conn.close();
                     rs.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
                }
             return null;
    }
  // Thay đổi tình trạng phòng theo số phòng
  // khi thêm phiếu thuê phòng
  // thanh toán hóa đơn
 public static int edittt(dsphong phong){
    Connection conn=null;
    PreparedStatement sttm=null;
        try {
            String sSQL="update `ds_phong` set `tinhtrangphong`=? where sophong=?";
            conn= ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setString(1, phong.getTinhtrangphong());  
            sttm.setString(2,phong.getSophong() );        
            if(sttm.executeUpdate()>0){
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
    }
 // lấy ra tiền phòng theo số phòng
 public static float tienphong(String sophong)
      {
          Connection conn= null;
         PreparedStatement sttm= null;
          ResultSet rs=null;
          float tiendv=0;
          try {
              String sql ="select giaphong from ds_phong where sophong=?";
            conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setString(1, sophong);
                 rs=sttm.executeQuery();
              while(rs.next())
              {
                  tiendv = rs.getFloat(1);                  
              }          
          } catch (Exception e) {
               System.out.println("Error: "+e.toString());
          }
          finally{
               try {
                     conn.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
          }    
        return tiendv;
      }
  public static String gettp(String  sophong){
    Connection conn=null;
    PreparedStatement sttm=null;
    ResultSet rs= null;
    String ttp = null;
        try {
            String sSQL="select tinhtrangphong from ds_phong where sophong=?";
            conn= ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);  
            sttm.setString(1,sophong);
            rs = sttm.executeQuery();
          while(rs.next())
          {
             ttp =rs.getString(1);
          }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return ttp; 
    }
}