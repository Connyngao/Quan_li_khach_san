/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.dichvu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class dichvudao {
    //Thêm dịch vụ 
    public int add(dichvu dv)
    {
       Connection conn=null;
       PreparedStatement sttm=null;
        try {
            String sSQL="INSERT INTO dich_vu(`madv`, `tendv`, `giadv`,`soluong`, `loaidv`,`tinhtrang`,`ghichu`) VALUES (?,?,?,?,?,?,?)";
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setString(1, dv.getMadv());
            sttm.setString(2, dv.getTendv());
            sttm.setInt(3, dv.getGiadv());
            sttm.setInt(4, dv.getSoluong());
            sttm.setString(5, dv.getLoaidv());
            sttm.setString(6, dv.getTinhtrang());
            sttm.setString(7, dv.getGhichu());
            if(sttm.executeUpdate()>0){
                System.out.println("Them thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
    }
    // sua dich vu
     public int edit(dichvu dv)
    {
       Connection conn=null;
       PreparedStatement sttm=null;
        try {
            String sSQL=" update dich_vu set `tendv`=?, `giadv`=?,`soluong`=? ,`loaidv`=?,`tinhtrang`=?,`ghichu`=? where `madv`=?";
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
           sttm.setString(7, dv.getMadv());
            sttm.setString(1, dv.getTendv());
            sttm.setInt(2, dv.getGiadv());
            sttm.setString(4, dv.getLoaidv());
            sttm.setInt(3, dv.getSoluong());
            sttm.setString(5, dv.getTinhtrang());
            sttm.setString(6, dv.getGhichu());
            if(sttm.executeUpdate()>0){
                System.out.println("sua thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
    }
     //xoa dich vu
   public int delete(String dv){
    Connection conn=null;
    PreparedStatement sttm=null;
        try {
            String sSQL="DELETE FROM `dich_vu` WHERE madv=?";
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setString(1, dv );
            
            if(sttm.executeUpdate()>0){
                System.out.println("Xoa thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không xóa thành công
    return -1; 
    } 
   // lay het dich vu
   public static List<dichvu> getalldv()
      {
          List<dichvu> dvList= new ArrayList<>();
          Connection con= null;
          Statement sttm= null;
          ResultSet rs=null;
          try {
              String sql="select `madv`,`tendv`,`giadv`,`soluong`,`loaidv`,`tinhtrang`,`ghichu` from `dich_vu` order by `giadv` desc";
              con=ketnoidb.getConnection();
              sttm=con.createStatement();
              rs=sttm.executeQuery(sql);
              while(rs.next())
              {
                 dichvu dv=new dichvu();
                  dv.setMadv(rs.getString(1));
                  dv.setTendv(rs.getString(2));
                  dv.setGiadv(rs.getInt(3));
                  dv.setSoluong(rs.getInt(4));
                  dv.setLoaidv(rs.getString(5));
                  dv.setTinhtrang(rs.getString(6));
                  dv.setGhichu(rs.getString(7));
                  dvList.add(dv);
                  
              }
          } catch (Exception e) {
              System.out.println("Error:" +e.toString());
          }
          finally
          {
              try {
                  con.close();
                  sttm.close();
                  rs.close();
              } catch (Exception e) {
              }
          }
          
          return dvList;
      }
   public static dichvu getkhBymadv(String madv){
         Connection conn =null;
         PreparedStatement sttm=null;
         ResultSet rs=null;
         dichvu dv=new dichvu();
             try {
                  String sql="select `madv`,`tendv`,`giadv`,`soluong`,`loaidv`,`tinhtrang`,`ghichu` from `dich_vu` WHERE madv=?";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setString(1, madv);
                 rs=sttm.executeQuery();
                 while(rs.next()){                    
                  dv.setMadv(rs.getString(1));
                  dv.setTendv(rs.getString(2));
                  dv.setSoluong(rs.getInt(4));
                  dv.setGiadv(rs.getInt(3));
                  dv.setLoaidv(rs.getString(5));
                  dv.setTinhtrang(rs.getString(6));
                  dv.setGhichu(rs.getString(7));
                     return dv;
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     conn.close();
                     rs.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
                }
             return null;
         }
    public static List<dichvu> getloaidv(String loaidv){
        
        List<dichvu> dvlisList = new ArrayList<>();
         Connection conn =null;
         PreparedStatement sttm=null;
         ResultSet rs=null;
         dichvu dv=new dichvu();
             try {
                  String sql="select `madv`,`tendv`,`giadv`,`soluong`,`loaidv`,`tinhtrang`,`ghichu` from `dich_vu` WHERE loaidv=? ORDER BY giadv";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setString(1, loaidv);
                 rs=sttm.executeQuery();
                 while(rs.next()){                    
                  dv.setMadv(rs.getString(1));
                  dv.setTendv(rs.getString(2));
                  dv.setSoluong(rs.getInt(4));
                  dv.setGiadv(rs.getInt(3));
                  dv.setLoaidv(rs.getString(5));
                  dv.setTinhtrang(rs.getString(6));
                  dv.setGhichu(rs.getString(7));
                  dvlisList.add(dv);
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     conn.close();
                     rs.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
                }
             return dvlisList;
 
}
    public static int getgiadv(String madv)
    {
         Connection conn= null;
         PreparedStatement sttm= null;
          ResultSet rs=null;
         int giadv = 0;
          try {
              String sql ="select giadv from dich_vu where madv=?";
            conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setString(1, madv);
                 rs=sttm.executeQuery();
              while(rs.next())
              {
                 giadv = rs.getInt(1);
                 
              }          
          } catch (Exception e) {
               System.out.println(" dichcudao getgiadv: "+e.toString());
          }
          finally{
               try {
                     conn.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
          }  
        return giadv;
    }
}
