/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.login;
import form.quan_li_khach_san.view.frm_login;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

/**
 *
 * @author user
 */
public class logindao {
    
    public static int dn(String username, String pass)
    {
        Connection cn= null;
        PreparedStatement sttm = null;
         ResultSet rs=null;
        int id =0;
        try {
            /// mai lafm
            
            String sql ="select id from users where  username=? and password=?";
            cn = ketnoidb.getConnection();
             sttm=cn.prepareStatement(sql);
             sttm.setString(1, username);
             sttm.setString(2, pass);
             rs=sttm.executeQuery();
            while(rs.next())
            {
                id = rs.getInt(1);
            } 
          } catch (Exception e) {
                 }
        finally
        {
            try {
                cn.close();
                rs.close();
                sttm.close();
            } catch (Exception e) {
            } finally {
            }
        }
               
        return id;
    }
     public static login manvlogin(String username, String pass)
    {
        Connection cn= null;
        PreparedStatement sttm = null;
         ResultSet rs=null;
        
        try {
            /// mai lafm
            
            String sql ="select id,username ,password,id_nv  from users where  username=? and password=?";
            cn = ketnoidb.getConnection();
             sttm=cn.prepareStatement(sql);
             sttm.setString(1, username);
             sttm.setString(2, pass);
             rs=sttm.executeQuery();
            while(rs.next())
            {
                login lg = new login();
                lg.setId(rs.getInt(1));
                lg.setUsers(rs.getString(2));
                lg.setPassword(rs.getString(3));
                lg.setManv(rs.getString(4));
                return  lg;
                
            } 
          } catch (Exception e) {
                 }
        finally
        {
            try {
                cn.close();
                rs.close();
                sttm.close();
            } catch (Exception e) {
            } finally {
            }
        }
               
        return null;
    }
     public static void main(String[] args) {
         System.out.println(manvlogin("admin", "admin"));
    }
}
