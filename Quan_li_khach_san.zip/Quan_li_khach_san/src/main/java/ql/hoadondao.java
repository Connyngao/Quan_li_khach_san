/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.hoadon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class hoadondao {
    public  int add(hoadon hd)
    {
        Connection cn= null;
        PreparedStatement sttm = null;
        try {
            String sql ="insert into hoa_don(id_kh,sophong,maphieudv,id_nv,ngaytra,chiphikhac,thanhtoan,ghichu) values(?,?,?,?,?,?,?,?) ";
            cn = ketnoidb.getConnection();
            sttm=cn.prepareStatement(sql);
            sttm.setInt(1, hd.getId());
            sttm.setString(2, hd.getSophong());
            sttm.setString(3, hd.getMaphieudv());
            sttm.setString(4, hd.getId_nv());
            sttm.setDate(5, hd.getNgaytra());
            sttm.setInt(6, hd.getChiphikhac());
            sttm.setFloat(7, hd.getThanhtoan());
            sttm.setString(8, hd.getGhichu());
            if (sttm.executeUpdate()>0) {
                return 1;               
            }
        } catch (Exception e) {
            System.out.println("ql.hoadondao.add():" +e.toString());
        }
        finally
        {
            try {
                cn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
        return -1;
    }
    // 
     public  int edit(hoadon hd)
    {
        Connection cn= null;
        PreparedStatement sttm = null;
        try {
            String sql ="update hoa_don set chiphikhac=?,thanhtoan=?,ghichu=? where id_kh=? and id=?";
            cn = ketnoidb.getConnection();
            sttm=cn.prepareStatement(sql);
            sttm.setInt(1, hd.getChiphikhac());
            sttm.setFloat(2, hd.getThanhtoan());
            sttm.setString(3, hd.getGhichu());
            sttm.setInt(4, hd.getId());
            sttm.setInt(5, hd.getMahd());
            if (sttm.executeUpdate()>0) {
                return 1;               
            }
        } catch (Exception e) {
            System.out.println("ql.hoadondao.edit(): " +e.toString());
        }
        finally
        {
            try {
                cn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
        return -1;
    }
    //
    public static  List<hoadon> getallhd()
    {
        List<hoadon> hdlList = new ArrayList<>();
        Connection cn= null;
        Statement sttm= null;
        ResultSet rs= null;
            try
            {
                String sql = "select id_kh,id,sophong,maphieudv,id_nv,ngaytra,chiphikhac,thanhtoan,ghichu from hoa_don order by id desc";  
                cn=ketnoidb.getConnection();
                sttm= cn.createStatement();
                rs=sttm.executeQuery(sql);
                while(rs.next()){
                    hoadon hd = new hoadon();
                    hd.setId(rs.getInt(1));
                    hd.setMahd(rs.getInt(2));
                    hd.setSophong(rs.getString(3));
                    hd.setMaphieudv(rs.getString(4));
                    hd.setId_nv(rs.getString(5));
                    hd.setNgaytra(rs.getDate(6));
                    hd.setChiphikhac(rs.getInt(7));
                    hd.setThanhtoan(rs.getFloat(8));
                    hd.setGhichu(rs.getString(9));                    
                    hdlList.add(hd);
            }
             } catch (Exception e) 
                {
                    System.out.println("ql.hoadondao.getallhd()"+e.toString());
                }
            finally
            {
                try {
                    cn.close();
                    sttm.close();
                    rs.close();
                } catch (Exception e) {
                }
            }
       return hdlList;
    }
     public static hoadon getkhByid(int id){
         Connection conn =null;
         PreparedStatement sttm=null;
         ResultSet rs=null;
         hoadon kh=new hoadon();
             try {
                  String sql="select id_kh,id,sophong,maphieudv,id_nv,ngaytra,chiphikhac,thanhtoan,ghichu from hoa_don where id_kh = ?";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setInt(1, id);
                 rs=sttm.executeQuery();
                 while(rs.next()){                    
                
                     kh.setId(rs.getInt(1));
                     kh.setMahd(rs.getInt(2));
                     kh.setSophong(rs.getString(3));
                     kh.setMaphieudv(rs.getString(4));
                     kh.setId_nv(rs.getString(5));
                     kh.setNgaytra(rs.getDate(6));
                     kh.setChiphikhac(rs.getInt(7));
                     kh.setThanhtoan(rs.getInt(8));
                     kh.setGhichu(rs.getString(9));
                  
                     return kh;
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     conn.close();
                     rs.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
                }
             return null;
         }
    public static int makh(String sophong)
      {
          Connection conn= null;
         PreparedStatement sttm= null;
          ResultSet rs=null;
          int id=0;
          try {
              String sql ="select max(id_kh) from hoa_don where sophong=?";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setString(1, sophong);
                 rs=sttm.executeQuery();
              while(rs.next())
              {
                  id = rs.getInt(1);                  
              }          
          } catch (Exception e) {
               System.out.println("ql phieuthuedv makh() : "+e.toString());
          }
          finally{
               try {
                     conn.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
          }    
        return id;
      }
    public static List<hoadon> thongkengay()
    {
        List<hoadon> hdList = new ArrayList<>();
        Connection cn = null;
        Statement sttm = null;
        ResultSet rs = null;
        try {
           cn = ketnoidb.getConnection();
            String sql ="Select ngaytra,sum(thanhtoan) from hoa_don group by ngaytra";
            sttm =cn.createStatement();
            rs = sttm.executeQuery(sql);
            while(rs.next())
            {
                hoadon hd= new hoadon();
                hd.setNgaytra(rs.getDate(1));
                hd.setThanhtoan(rs.getInt(2));
                hdList.add(hd);
            }
        } catch (Exception e) {
            System.out.println("thong ke theo ngay  hoadondao :" +e.toString());
        } finally {
            try {
                cn.close();
                sttm.close();
                rs.close();
            } catch (Exception e) {
            }
            
        }
        return hdList;
    }
    public static List<hoadon> thongkethang()
    {
        List<hoadon> hdList = new ArrayList<>();
        Connection cn = null;
        Statement sttm = null;
        ResultSet rs = null;
        try {
           cn = ketnoidb.getConnection();
            String sql ="Select month(ngaytra),sum(thanhtoan) from hoa_don group by month(ngaytra)";
            sttm =cn.createStatement();
            rs = sttm.executeQuery(sql);
            while(rs.next())
            {
                hoadon hd= new hoadon();
                hd.setChiphikhac(rs.getInt(1));
                hd.setThanhtoan(rs.getInt(2));
                hdList.add(hd);
            }
        } catch (Exception e) {
            System.out.println("thong ke theo thang  hoadondao :" +e.toString());
        } finally {
            try {
                cn.close();
                sttm.close();
                rs.close();
            } catch (Exception e) {
            }
            
        }
        return hdList;
    }
    public static List<hoadon> thongkenam()
    {
        List<hoadon> hdList = new ArrayList<>();
        Connection cn = null;
        Statement sttm = null;
        ResultSet rs = null;
        try {
           cn = ketnoidb.getConnection();
            String sql ="Select year(ngaytra) as nam,sum(thanhtoan) from hoa_don group by year(ngaytra)";
            sttm =cn.createStatement();
            rs = sttm.executeQuery(sql);
            while(rs.next())
            {
                hoadon hd= new hoadon();
                hd.setChiphikhac(rs.getInt(1));
                hd.setThanhtoan(rs.getInt(2));
                hdList.add(hd);
            }
        } catch (Exception e) {
            System.out.println("thong ke theo nam hoadondao :" +e.toString());
        } finally {
            try {
                cn.close();
                sttm.close();
                rs.close();
            } catch (Exception e) {
            }
            
        }
        return hdList;
    }
    public static long ngaythue(int makh)
      {
          Connection conn= null;
         PreparedStatement sttm= null;
          ResultSet rs=null;
         long pt = 0;
          try {
              String sql ="select  DATEDIFF( ngaytra, ngaythue ) from phieu_thue,hoa_don where phieu_thue.id =? ";
            conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setInt(1, makh);
                 rs=sttm.executeQuery();
              while(rs.next())
              {
                 pt = rs.getLong(1);
                 
              }          
          } catch (Exception e) {
               System.out.println("ql phieuthuedv ngaythue(): "+e.toString());
          }
          finally{
               try {
                     conn.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
          }  
        return pt;
      }
   public static float tiendv(int makh)
          {
              Connection conn= null;
             PreparedStatement sttm= null;
              ResultSet rs=null;
              float tiendv=0;
              try {
                  String sql ="select sum(thanhtien) from phieu_thue_dv where id = ?";
                conn=ketnoidb.getConnection();
                     sttm =conn.prepareStatement(sql);
                     sttm.setInt(1, makh);
                     rs=sttm.executeQuery();
                  while(rs.next())
                  {
                      tiendv = rs.getFloat(1);                  
                  }          
              } catch (Exception e) {
                   System.out.println("ql phieuthuedv tiendv(): "+e.toString());
              }
              finally{
                   try {
                         conn.close();
                         sttm.close();
                     } catch (Exception e) {
                     }
              }    
            return tiendv;
          }
}
