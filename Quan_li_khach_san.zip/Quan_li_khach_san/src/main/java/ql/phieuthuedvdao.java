/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;


import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.dichvu;
import form.quan_li_khach_san.moder.phieuthuedv;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class phieuthuedvdao {
 
    // thêm phiếu thuê dịch vụ
    public  int add(phieuthuedv pdv)
  {
      Connection  con= null;
      PreparedStatement sttm = null;
      try {
      
           String sql="insert into phieu_thue_dv(maphieudv,id,madv,soluong,thanhtien,ghichu) Values(?,?,?,?,?,?)";
           con = ketnoidb.getConnection();
           sttm = con.prepareStatement(sql);
           sttm.setString(1, pdv.getMaphieudv());
           sttm.setInt(2, pdv.getId()); 
           sttm.setString(3, pdv.getMadv());
           sttm.setInt(4, pdv.getSoluong());
           sttm.setInt(5, pdv.getThanhtien());
           sttm.setString(6, pdv.getGhichu());
            if(sttm.executeUpdate()>0){     
                return 1;
            }
      } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                con.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
     
  }


    //them phong
    public int edit(phieuthuedv dv){
        Connection conn=null;
        PreparedStatement sttm=null;
            try {
                String sSQL="update `phieu_thue_dv` set soluong=?,thanhtien=?, `ghichu`=? where  madv=? and `maphieudv`=? and id=?" ;
                conn=ketnoidb.getConnection();
                sttm=conn.prepareStatement(sSQL);
               
                sttm.setInt(1,dv.getSoluong());
                sttm.setInt(2, dv.getThanhtien());
                sttm.setString(3,dv.getGhichu());
                 sttm.setString(4,dv.getMadv());
                sttm.setString(5,dv.getMaphieudv());
                sttm.setInt(6,dv.getId());
                if(sttm.executeUpdate()>0){

                    return 1;
                }
            } catch (Exception e) {
                System.out.println("Error: "+e.toString());
            } finally {
                try {
                    conn.close();
                    sttm.close();
                } catch (Exception e) {
                }
            }
        // neu không thêm thành công
        return -1; 
        }
    // lấy ra danh sách các dịch vụ
    public static List<dichvu> getalldv1()
          {
              List<dichvu> dvList= new ArrayList<>(); 
              Connection con= null;
              Statement sttm= null;
              ResultSet rs=null;
              try {
                  String sql="select `madv`,`tendv`,`giadv`,`loaidv`,`tinhtrang` from `dich_vu` order by `giadv` desc";
                  con=ketnoidb.getConnection();
                  sttm=con.createStatement();
                  rs=sttm.executeQuery(sql);
                  while(rs.next())
                  {
                     dichvu dv=new dichvu();
                      dv.setMadv(rs.getString(1));
                      dv.setTendv(rs.getString(2));
                      dv.setGiadv(rs.getInt(3));
                      dv.setLoaidv(rs.getString(4));
                      dv.setTinhtrang(rs.getString(5));

                      dvList.add(dv);

                  }
              } catch (Exception e) {
                  System.out.println("Error:" +e.toString());
              }
              finally
              {
                  try {
                      con.close();
                      sttm.close();
                      rs.close();
                  } catch (Exception e) {
                  }
              }

              return dvList;
          }
    // lấy ra toàn bộ danh sách phiếu thuê
    public  static List<phieuthuedv>getallpdv()
        {
                List<phieuthuedv> pdvList= new ArrayList<>();
              Connection con= null; 
              Statement sttm= null;
              ResultSet rs=null;
              try {
                  String sql="select `id`,`maphieudv`,`madv`,`soluong`,`thanhtien`,`ghichu` from phieu_thue_dv order by id desc";
                       //   + "where phieu_thue_dv.id= phieu_thue_phong.id";
                  con=ketnoidb.getConnection();
                  sttm=con.createStatement();
                  rs=sttm.executeQuery(sql);
                    while(rs.next())
                     {
                      phieuthuedv dv=new phieuthuedv();
                      dv.setId(rs.getInt(1));
                      dv.setMaphieudv(rs.getString(2));
                      dv.setMadv(rs.getString(3));
                      dv.setSoluong(rs.getInt(4));
                      dv.setThanhtien(rs.getInt(5));
                      dv.setGhichu(rs.getString(6));
                      pdvList.add(dv);     
                     }
                } catch (Exception e) {
                  System.out.println(" phieu thue phong :" );
                    }
              finally
              {
                  try {
                      con.close();
                      sttm.close();
                      rs.close();
                     } catch (Exception e) {
                         }
              }

              return pdvList;        
            }
    // xóa phiếu dịch vụ    
     public int delete(String pdv){
        Connection conn=null;
        PreparedStatement sttm=null;
            try {
                String sSQL="DELETE FROM `phieu_thue_dv` WHERE maphieuthue=?";
                conn=ketnoidb.getConnection();
                sttm=conn.prepareStatement(sSQL);
                sttm.setString(1, pdv );

                if(sttm.executeUpdate()>0){
                    System.out.println("Xoa thanh cong.");
                    return 1;
                }
            } catch (Exception e) {
                System.out.println("Error: "+e.toString());
            } finally {
                try {
                    conn.close();
                    sttm.close();
                } catch (Exception e) {
                }
            }
        // neu không xóa thành công
        return -1; 
        } 
     // lấy ra id khách hàng theo số phòng đang thuê
     public static int makh(String sophong)
          {
              Connection conn= null;
             PreparedStatement sttm= null;
              ResultSet rs=null;
              int id=0;
              try {
                  String sql ="select max(id) from phieu_thue_phong where sophong=?";
                conn=ketnoidb.getConnection();
                     sttm =conn.prepareStatement(sql);
                     sttm.setString(1, sophong);
                     rs=sttm.executeQuery();
                  while(rs.next())
                  {
                      id = rs.getInt(1);                  
                  }          
              } catch (Exception e) {
                   System.out.println("ql phieuthuedv makh() : "+e.toString());
              }
              finally{
                   try {
                         conn.close();
                         sttm.close();
                     } catch (Exception e) {
                     }
              }    
            return id;
          }
     public static phieuthuedv getbyid(int id,String madv)
     {
            Connection conn =null;
             PreparedStatement sttm=null;
             ResultSet rs=null;
             phieuthuedv pdv=new phieuthuedv();
                 try {
                     String sqlString="SELECT `maphieudv`, `madv`, `soluong`,`thanhtien`, `ghichu` FROM `phieu_thue_dv` WHERE id=? and madv=?";
                     conn=ketnoidb.getConnection();
                     sttm =conn.prepareStatement(sqlString);
                     sttm.setInt(1, id);
                     sttm.setString(2, madv);
                     rs=sttm.executeQuery();
                     while(rs.next()){                    
                         pdv.setMaphieudv(rs.getString(1));

                         pdv.setMadv(rs.getString(2));
                         pdv.setSoluong(rs.getInt(3));
                         pdv.setThanhtien(rs.getInt(4));
                         pdv.setGhichu(rs.getString(5));

                         return pdv;
                     }

                 } catch (Exception e) {
                     System.out.println("ql phieuthuedv getbyid(): "+e.toString());
                 } finally {
                     try {
                         conn.close();
                         rs.close();
                         sttm.close();
                     } catch (Exception e) {
                     }
                    }
                 return null;
    }
        // lấy mã dịch vụ theo số phòng
     public static String maphieudv(String sophong)
          {
              Connection conn= null;
             PreparedStatement sttm= null;
              ResultSet rs=null;
              String maphieudv=null;
              try {
                  String sql ="select maphieudv from phieu_thue_dv where id = (select max(id) from phieu_thue_phong where sophong=?)";
                conn=ketnoidb.getConnection();
                     sttm =conn.prepareStatement(sql);
                     sttm.setString(1, sophong);
                     rs=sttm.executeQuery();
                  while(rs.next())
                  {
                      maphieudv = rs.getString(1);                  
                  }          
              } catch (Exception e) {
                   System.out.println("ql phieuthuedv maphieudv(): "+e.toString());
              }
              finally{
                   try {
                         conn.close();
                         sttm.close();
                     } catch (Exception e) {
                     }
              }    
            return maphieudv;
          }
     // tính tiền dịch vụ theo số phòng
     public static float tiendv(String sophong)
          {
              Connection conn= null;
             PreparedStatement sttm= null;
              ResultSet rs=null;
              float tiendv=0;
              try {
                  String sql ="select sum(thanhtien) from phieu_thue_dv where id = (select max(id) from phieu_thue_phong where sophong=?)";
                conn=ketnoidb.getConnection();
                     sttm =conn.prepareStatement(sql);
                     sttm.setString(1, sophong);
                     rs=sttm.executeQuery();
                  while(rs.next())
                  {
                      tiendv = rs.getFloat(1);                  
                  }          
              } catch (Exception e) {
                   System.out.println("ql phieuthuedv tiendv(): "+e.toString());
              }
              finally{
                   try {
                         conn.close();
                         sttm.close();
                     } catch (Exception e) {
                     }
              }    
            return tiendv;
          }
     // lấy thong tin phiếu thuê  theo id
       public  static List<phieuthuedv>getpdvbyid( int id)
            {
                List<phieuthuedv> pdvList= new ArrayList<>();
              Connection conn= null; 
              PreparedStatement sttm= null;
              ResultSet rs=null;

                 try {
                     String sqlString="SELECT `maphieudv`, `madv`, `soluong`,`thanhtien`, `ghichu` FROM `phieu_thue_dv` WHERE id=?";
                     conn=ketnoidb.getConnection();
                     sttm =conn.prepareStatement(sqlString);
                     sttm.setInt(1, id);
                     rs=sttm.executeQuery();
                     while(rs.next()){   
                         phieuthuedv pdv=new phieuthuedv();
                         pdv.setMaphieudv(rs.getString(1));
                         pdv.setMadv(rs.getString(2));
                         pdv.setSoluong(rs.getInt(3));
                         pdv.setThanhtien(rs.getInt(4));
                         pdv.setGhichu(rs.getString(5));
                        pdvList.add(pdv);
                     }

                 } catch (Exception e) {
                     System.out.println("ql phieuthuedv getbyid(): "+e.toString());
                 } finally {
                     try {
                         conn.close();
                         rs.close();
                         sttm.close();
                     } catch (Exception e) {
                     }
                    }
                 return pdvList;
    }
      public static void main(String[] args) {
           phieuthuedvdao dao = new phieuthuedvdao();
           phieuthuedv dv= new phieuthuedv("PDV_P202",96 , "GT-caraoke", 10, 100000,"");
        
           System.out.println(dao.edit(dv));
    }
}