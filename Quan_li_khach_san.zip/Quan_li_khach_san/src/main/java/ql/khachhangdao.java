/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.khachhang;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class khachhangdao {
    //getcount
    

    
    //thêm khách hàng
     public  int add(khachhang kh){
    Connection conn=null;
    PreparedStatement sttm=null;
   // PreparedStatement sttm1=null;
        try {
            String sSQL="INSERT INTO khach_hang(`id`,`hodem`, `ten`, `gioitinh`, `ngaysinh`,`cccd`) VALUES (?,?,?,?,?,?)";
           
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setInt(1,kh.getId());
            sttm.setString(2, kh.getHodem());
            sttm.setString(3, kh.getTen());
            sttm.setBoolean(4, kh.isGioitinh());
            sttm.setDate(5, kh.getNgaysinh());
            sttm.setInt(6, kh.getCccd());    
            if(sttm.executeUpdate()>0){
                System.out.println("Them thanh cong.");
                return 1;
                
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
         
             
         
    }
     // sửa khách hàng
     public static int edit(khachhang kh){
    Connection conn=null;
    PreparedStatement sttm=null;
        try {
             String sSQL="update `khach_hang` set `hodem`=?, `ten`=?, `gioitinh`=?, `ngaysinh`=?,`cccd`=? where `id`=?"
                   ;
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setString(1, kh.getHodem());
            sttm.setString(2, kh.getTen());
            sttm.setBoolean(3, kh.isGioitinh());
            sttm.setDate(4, kh.getNgaysinh());
            sttm.setInt(5, kh.getCccd());
            sttm.setInt(6, kh.getId());
           
            if(sttm.executeUpdate()>0){
                System.out.println("Them thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
    }
     // Xóa khách hàng
     public static int delete(int id){
    Connection conn=null;
    PreparedStatement sttm=null;
        try {
            String sSQL="DELETE FROM `khach_hang` WHERE id=?";
            conn=ketnoidb.getConnection();
            sttm=conn.prepareStatement(sSQL);
            sttm.setInt(1, id);
            
            if(sttm.executeUpdate()>0){
                System.out.println("Xoa thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                conn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không xóa thành công
    return -1; 
    }
    // Lấy toàn bộ thông tin từ CSDL đưa vào List
         public static List<khachhang> getAllkhachhang(){
             List<khachhang> list=new ArrayList<>();
             Connection conn=null;
             Statement sttm=null;
             ResultSet rs=null;
             try {
                 String sSQL="SELECT `id`, `hodem`, `ten`, `gioitinh`, `ngaysinh`,`cccd` FROM `khach_hang` ORDER BY id DESC";
                 conn=ketnoidb.getConnection();
                 sttm=conn.createStatement();
                 rs=sttm.executeQuery(sSQL);
                 while(rs.next()){
                     khachhang kh=new khachhang();
                     kh.setId(rs.getInt(1));
                     kh.setHodem(rs.getString(2));
                     kh.setTen(rs.getString(3));
                     kh.setGioitinh(rs.getBoolean(4));
                     kh.setNgaysinh(rs.getDate(5));
                     kh.setCccd(rs.getInt(6));
                     list.add(kh);
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     rs.close();
                     sttm.close();
                     conn.close();
                 } catch (Exception e) {
                 }
             }
             return list;
         }
         public static khachhang getkhByname(String name){
         Connection conn =null;
         PreparedStatement sttm=null;
         ResultSet rs=null;
         khachhang kh=new khachhang();
             try {
                 String sqlString="SELECT `id`, `hodem`, `ten`, `gioitinh`, `ngaysinh`,`cccd` FROM `khach_hang` WHERE ten like ? "
                         + " or cccd like ? or hodem like ? group by cccd";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sqlString);
                 sttm.setString(1, name);
                 sttm.setString(2, name);
                 sttm.setString(3, name);
                 rs=sttm.executeQuery();
                 while(rs.next()){                    
                     kh.setId(rs.getInt(1));
                     kh.setHodem(rs.getString(2));
                     kh.setTen(rs.getString(3));
                     kh.setGioitinh(rs.getBoolean(4));
                     kh.setNgaysinh(rs.getDate(5));
                     kh.setCccd(rs.getInt(6));
                     return kh;
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     conn.close();
                     rs.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
                }
             return null;
         }       
}
