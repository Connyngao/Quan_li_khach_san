/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.dsphong;
import form.quan_li_khach_san.moder.thongtinphong;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class thongtinphongdao {
  // thong tin tất cả các phòng  
    public static List<thongtinphong> getallttp()
    {
        List<thongtinphong> ttplist = new ArrayList<>();
        Connection con = null;
       Statement sttm= null;
          ResultSet rs=null;
        try{
            String sql = "select `sophong`,`loaiphong`,`giaphong`,`tinhtrangphong`,`ghichu` from ds_phong order by sophong asc";
                  
            con=ketnoidb.getConnection();
            sttm=con.createStatement();
            rs=sttm.executeQuery(sql);
            while(rs.next())
            {
                thongtinphong ttp = new thongtinphong();
                ttp.setSophong(rs.getString(1));
                ttp.setLoaiphong(rs.getString(2));
                ttp.setGiaphong(rs.getInt(3));
                ttp.setTinhtrangphong(rs.getString(4));
                ttp.setGhichu(rs.getString(5));
                ttplist.add(ttp);
                
            }
        }
        catch(Exception ex)
        {
            System.out.println("Error" + ex.toString());
        }
        finally
        {
            try {
                con.close();
                rs.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
        return ttplist;
    }
  // lấy ra danh sách thông tin phòng theo tình trạng phòng
    public static List<dsphong> locphong(String ttp)
    {
        List<dsphong> dsphong = new ArrayList<>();
          Connection conn =null;
         PreparedStatement sttm=null;
         ResultSet rs=null;
             try {
                  String sql="select `sophong`,`loaiphong`,`giaphong`,`tinhtrangphong`,`ghichu` from `ds_phong` WHERE tinhtrangphong=?";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setString(1, ttp);
                 rs=sttm.executeQuery();
                 while(rs.next()){  
                    dsphong dv=new dsphong();
                    dv.setSophong(rs.getString(1));
                    dv.setLoaiphong(rs.getString(2));
                    dv.setGiaphong(rs.getInt(3));              
                    dv.setTinhtrangphong(rs.getString(4));                 
                    dv.setGhichu(rs.getString(5));
                     dsphong.add(dv);
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     conn.close();
                     rs.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
                }
             return dsphong;
    }
  // phiếu thuê phòng 
   
     public static List<thongtinphong> getallptp()
    {
        List<thongtinphong> ttplist = new ArrayList<>();
        Connection con = null;
       Statement sttm= null;
          ResultSet rs=null;
        try{
            String sql = "select `id`,`sophong`,`maphieudv` from phieu_thue_phong order by id desc";
                  
            con=ketnoidb.getConnection();
            sttm=con.createStatement();
            rs=sttm.executeQuery(sql);
            while(rs.next())
            {
                thongtinphong ttp = new thongtinphong();
                ttp.setId(rs.getInt(1));
                ttp.setSophong(rs.getString(2));
                ttp.setGhichu(rs.getString(3));
                ttplist.add(ttp);
                
            }
        }
        catch(Exception ex)
        {
            System.out.println("Error" + ex.toString());
        }
        finally
        {
            try {
                con.close();
                rs.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
        return ttplist;
}
}
