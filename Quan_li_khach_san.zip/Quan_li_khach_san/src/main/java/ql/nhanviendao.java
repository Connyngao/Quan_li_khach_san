/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.nhanvien;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class nhanviendao {
    
    // them nhan vien
    public  int add(nhanvien nv)
    {
        Connection cn = null;
        PreparedStatement sttm = null;
        try {
            String sql ="insert into nhan_vien(id,hodem,ten,gioitinh,ngaysinh,sdt,cccd,chucvu,diachi) values(?,?,?,?,?,?,?,?,?)";
            cn= ketnoidb.getConnection();
            sttm=cn.prepareStatement(sql);
            sttm.setString(1, nv.getId());
            sttm.setString(2, nv.getHodem());
            sttm.setString(3, nv.getTen());
            sttm.setBoolean(4, nv.isGioitinh());
            sttm.setDate(5, nv.getNgaysinh());
            sttm.setString(6, nv.getSdt());
            sttm.setInt(7, nv.getCccd());
            sttm.setString(8, nv.getChucvu());
            sttm.setString(9, nv.getDiachi());
            
            if (sttm.executeUpdate()>0) {
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Lỗi thêm nhan viên : " + e.toString());
        }
        finally
        {
            try {
                cn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
      return 0;
    }
    
    public  int edit(nhanvien nv)
    {
        Connection cn = null;
        PreparedStatement sttm = null;
        try {
            String sql ="update nhan_vien set hodem=?,ten=?,gioitinh=?,ngaysinh=?,sdt=?,cccd=?,chucvu=?,diachi=? where id=?";
            cn= ketnoidb.getConnection();
            sttm=cn.prepareStatement(sql);
            sttm.setString(1, nv.getHodem());
            sttm.setString(2, nv.getTen());
            sttm.setBoolean(3, nv.isGioitinh());
            sttm.setDate(4, nv.getNgaysinh());
            sttm.setString(5, nv.getSdt());
            sttm.setInt(6, nv.getCccd());
            sttm.setString(7, nv.getChucvu());
            sttm.setString(8, nv.getDiachi());
            sttm.setString(9, nv.getId());
            if (sttm.executeUpdate()>0) {
                return  1;
            }
        } catch (Exception e) {
            System.out.println("Lỗi thêm nhan viên : " + e.toString());
        }
        finally
        {
            try {
                cn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
      return 0;
    }
    public int delete(String id)
    {
        Connection cn = null;
        PreparedStatement sttm = null;
        try {
            String sql = "delete from nhan_vien where id =?";
            cn = ketnoidb.getConnection();
            sttm = cn.prepareStatement(sql);
             sttm.setString(1, id);
            
            if(sttm.executeUpdate()>0){
                return 1;
            }
        } catch (Exception e) {
            System.out.println("XÓA THẤT BẠI :" +e.toString());
        }
        finally{
            try {
                cn.close();
                sttm.close();
               } catch (Exception e) {
                    }
        }
        return 0;
    }
    public static List<nhanvien> getAllNhanvien()
    {
        List<nhanvien> nvlList = new ArrayList<>();
        Connection cn = null;
        Statement sttm = null;
        ResultSet rs = null;
        try {
            String sql = "select id,hodem,ten,gioitinh,ngaysinh,sdt,cccd,chucvu,diachi from nhan_vien order by id desc";
            cn= ketnoidb.getConnection();
            sttm = cn.createStatement();
            rs = sttm.executeQuery(sql);
            while(rs.next()){
                nhanvien nv = new nhanvien();
                nv.setId(rs.getString(1));
                nv.setHodem(rs.getString(2));
                nv.setTen(rs.getString(3));
                nv.setGioitinh(rs.getBoolean(4));
                nv.setNgaysinh(rs.getDate(5));
                nv.setSdt(rs.getString(6));
                nv.setCccd(rs.getInt(7));
                nv.setChucvu(rs.getString(8));
                nv.setDiachi(rs.getString(9));
                nvlList.add(nv);
            }
        } catch (Exception e) {
            System.out.println("lay danh sach nhan vien that bai"+ e.toString());
        }
        finally{
            try {
                cn.close();
                sttm.close();
                rs.close();
            } catch (Exception e) {
            }
        }
        return nvlList;
    }
    public nhanvien getbyid(String id){
         Connection conn =null;
         PreparedStatement sttm=null;
         ResultSet rs=null;
         nhanvien nv=new nhanvien();
             try {
                 String sqlString="select id,hodem,ten,gioitinh,ngaysinh,sdt,cccd,chucvu,diachi from nhan_vien where id =?";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sqlString);
                 sttm.setString(1, id);
                 rs=sttm.executeQuery();
                 while(rs.next()){                    
                    nv.setId(rs.getString(1));
                    nv.setHodem(rs.getString(2));
                    nv.setTen(rs.getString(3));
                    nv.setGioitinh(rs.getBoolean(4));
                    nv.setNgaysinh(rs.getDate(5));
                    nv.setSdt(rs.getString(6));
                    nv.setCccd(rs.getInt(7));
                    nv.setChucvu(rs.getString(8));
                    nv.setDiachi(rs.getString(9));
                    return nv;
                 }
                 
             } catch (Exception e) {
                    System.out.println("lay nhan vien theo id that bai: "+e.toString());
             } finally {
                 try {
                     conn.close();
                     rs.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
                }
             return null;
    }
}
