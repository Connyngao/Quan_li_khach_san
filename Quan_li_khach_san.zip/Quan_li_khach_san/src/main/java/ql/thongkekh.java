/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.khachhang;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class thongkekh extends khachhang{
    
    private int solan;

    public int getSolan() {
        return solan;
    }

    public void setSolan(int solan) {
        this.solan = solan;
    }

    @Override
    public String toString() {
        return "thongkekh{" + "solan=" + solan + '}';
    }

    public thongkekh(int solan, String hodem, String ten, boolean gioitinh, Date ngaysinh, int cccd) {
        super(hodem, ten, gioitinh, ngaysinh, cccd);
        this.solan = solan;
    }

 
    
    public thongkekh() {
    }  
     public static List<thongkekh> getAllkhachhang(){
             List<thongkekh> list=new ArrayList<>();
             Connection conn=null;
             Statement sttm=null;
             ResultSet rs=null;
             try {
                 String sSQL="SELECT  `hodem`, `ten`, `gioitinh`, `ngaysinh`,`cccd`,count(cccd) FROM `khach_hang` group BY cccd ";
                 conn=ketnoidb.getConnection();
                 sttm=conn.createStatement();
                 rs=sttm.executeQuery(sSQL);
                 while(rs.next()){
                     thongkekh kh=new thongkekh();
                     kh.setHodem(rs.getString(1));
                     kh.setTen(rs.getString(2));
                     kh.setGioitinh(rs.getBoolean(3));
                     kh.setNgaysinh(rs.getDate(4));
                     kh.setCccd(rs.getInt(5));
                     kh.setSolan(rs.getInt(6));
                     list.add(kh);
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     rs.close();
                     sttm.close();
                     conn.close();
                 } catch (Exception e) {
                 }
             }
             return list;
         }
      public static List<thongkekh> khtren3lan(){
             List<thongkekh> list=new ArrayList<>();
             Connection conn=null;
             Statement sttm=null;
             ResultSet rs=null;
             try {
                 String sSQL="SELECT  `hodem`, `ten`, `gioitinh`, `ngaysinh`,`cccd`,count(cccd) FROM `khach_hang` group by cccd ";
                 conn=ketnoidb.getConnection();
                 sttm=conn.createStatement();
                 rs=sttm.executeQuery(sSQL);
                 while(rs.next()){
                     if(rs.getInt(6)>=3){
                     thongkekh kh=new thongkekh();
                     kh.setHodem(rs.getString(1));
                     kh.setTen(rs.getString(2));
                     kh.setGioitinh(rs.getBoolean(3));
                     kh.setNgaysinh(rs.getDate(4));
                     kh.setCccd(rs.getInt(5));
                      kh.setSolan(rs.getInt(6));
                     list.add(kh);
                     }
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     rs.close();
                     sttm.close();
                     conn.close();
                 } catch (Exception e) {
                 }
             }
             return list;
         }
      public static List<thongkekh> khduoi3lan(){
             List<thongkekh> list=new ArrayList<>();
             Connection conn=null;
             Statement sttm=null;
             ResultSet rs=null;
             try {
                 String sSQL="SELECT  `hodem`, `ten`, `gioitinh`, `ngaysinh`,`cccd`,count(cccd) FROM `khach_hang` group by cccd";
                 conn=ketnoidb.getConnection();
                 sttm=conn.createStatement();
                 rs=sttm.executeQuery(sSQL);
                 while(rs.next()){
                     if(rs.getInt(6)<3){
                     thongkekh kh=new thongkekh();
                     kh.setHodem(rs.getString(1));
                     kh.setTen(rs.getString(2));
                     kh.setGioitinh(rs.getBoolean(3));
                     kh.setNgaysinh(rs.getDate(4));
                     kh.setCccd(rs.getInt(5));
                      kh.setSolan(rs.getInt(6));
                     list.add(kh);
                     }
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     rs.close();
                     sttm.close();
                     conn.close();
                 } catch (Exception e) {
                 }
             }
             return list;
         }
      public static void main(String[] args) {
          System.out.println(khtren3lan());
          System.out.println(khduoi3lan());
    }

}
