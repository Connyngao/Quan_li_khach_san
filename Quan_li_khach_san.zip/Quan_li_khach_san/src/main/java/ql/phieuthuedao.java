/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ql;

import form.quan_li_khach_san.connectdb.ketnoidb;
import form.quan_li_khach_san.moder.khachhang;
import form.quan_li_khach_san.moder.phieuthue;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class phieuthuedao {

    public int add(phieuthue pt)
    {
        khachhang kh= new khachhang();
        Connection  cn=null;
        PreparedStatement sttm = null;
        try {
            String sql = "insert into phieu_thue(`sophong`,`hodem`,`ten`,`gioitinh`,`ngaysinh`,`cccd`,`ngaythue`,`ghichu`) Values(?,?,?,?,?,?,?,?)";
            cn = ketnoidb.getConnection();
            sttm=cn.prepareStatement(sql);
            sttm.setString(1, pt.getSophong());
            sttm.setString(2, pt.getHodem());
            sttm.setString(3, pt.getTen());
            sttm.setBoolean(4, pt.isGioitinh());
            sttm.setDate(5, pt.getNgaysinh());
            sttm.setInt(6, pt.getCcd());
            sttm.setDate(7,pt.getNgaythue());
            sttm.setString(8, pt.getGhichu());
            if (sttm.executeUpdate()>0) {  
              
                return 1;
            }
        } catch (Exception e) {
        } finally{
            try {
                cn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
            
        return -1;
    }
    
    // sua phieu thue 
         public int edit(phieuthue pt)
    {
       Connection cn=null;
       PreparedStatement sttm=null;
        try {
            String sql = "update phieu_thue set `sophong`=?,`hodem`=?,`ten`=?,`gioitinh`=?,`ngaysinh`=?,`cccd`=?,`ngaythue`=?,`ghichu`=? where id=?";
            cn = ketnoidb.getConnection();
            sttm=cn.prepareStatement(sql);
            sttm.setString(1, pt.getSophong());
            sttm.setString(2, pt.getHodem());
            sttm.setString(3, pt.getTen());
            sttm.setBoolean(4, pt.isGioitinh());
            sttm.setDate(5, pt.getNgaysinh());
            sttm.setInt(6, pt.getCcd());
            sttm.setDate(7,pt.getNgaythue());
            sttm.setString(8, pt.getGhichu());
            sttm.setInt(9, pt.getId());
            if(sttm.executeUpdate()>0){
                System.out.println("sua thanh cong.");
                return 1;
            }
        } catch (Exception e) {
            System.out.println("Error: "+e.toString());
        } finally {
            try {
                cn.close();
                sttm.close();
            } catch (Exception e) {
            }
        }
    // neu không thêm thành công
    return -1; 
    }
    // lấy tất cả khách hàng đưa vào list rồi trả về 1 list kiểu arraylist
    public static List<phieuthue> getAllkh(){
             List<phieuthue> khlisList = new ArrayList<>();      
             Connection conn=null;
             Statement sttm=null;
             ResultSet rs=null;
             try {
                 String sSQL="SELECT id,`sophong`,`hodem`,`ten`,`gioitinh`,`ngaysinh`,`cccd`,`ngaythue`,`ghichu` from phieu_thue order by id desc";
                 conn=ketnoidb.getConnection();
                 sttm=conn.createStatement();
                 rs=sttm.executeQuery(sSQL);
                 while(rs.next()){
                     phieuthue kh = new phieuthue();
                     kh.setId(rs.getInt(1));
                     kh.setSophong(rs.getString(2));
                     kh.setHodem(rs.getString(3));
                     kh.setTen(rs.getString(4));
                     kh.setGioitinh(rs.getBoolean(5));
                     kh.setNgaysinh(rs.getDate(6));
                     kh.setCcd(rs.getInt(7));
                     kh.setNgaythue(rs.getDate(8));
                     kh.setGhichu(rs.getString(9));
                     khlisList.add(kh);
                 } 
             } catch (Exception e) {
                 System.out.println("loi lay ra danh sach khach hang  "+e.toString());
             } finally {
                 try {
                     rs.close();
                     sttm.close();
                     conn.close();
                 } catch (Exception e) {
                 }
             }
             return khlisList;
}
    // lấy phiếu thuê bằng id
    //
    public  phieuthue getkhByid(int sp){
         Connection conn =null;
         PreparedStatement sttm=null;
         ResultSet rs=null;
         phieuthue kh=new phieuthue();
             try {
                  String sql="SELECT id,`sophong`,`hodem`,`ten`,`gioitinh`,`ngaysinh`,`cccd`,`ngaythue`,`ghichu` from phieu_thue where id=?";
                 conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setInt(1, sp);
                 rs=sttm.executeQuery();
                 while(rs.next()){                    
                
                     kh.setId(rs.getInt(1));
                     kh.setSophong(rs.getString(2));
                     kh.setHodem(rs.getString(3));
                     kh.setTen(rs.getString(4));
                     kh.setGioitinh(rs.getBoolean(5));
                     kh.setNgaysinh(rs.getDate(6));
                     kh.setCcd(rs.getInt(7));
                     kh.setNgaythue(rs.getDate(8));
                     kh.setGhichu(rs.getString(9));
                  
                     return kh;
                 }
                 
             } catch (Exception e) {
                 System.out.println("Error: "+e.toString());
             } finally {
                 try {
                     conn.close();
                     rs.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
                }
             return null;
         }
  /// tinh so ngay thue theo so phong  
  public static long ngaythue(String sophong)
      {
          Connection conn= null;
         PreparedStatement sttm= null;
          ResultSet rs=null;
         long pt = 0;
          try {
              String sql ="select  DATEDIFF( CURDATE(), ngaythue ) from phieu_thue where id = (select max(id) from phieu_thue_phong where sophong=?)";
            conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setString(1, sophong);
                 rs=sttm.executeQuery();
              while(rs.next())
              {
                 pt = rs.getLong(1);
                 
              }          
          } catch (Exception e) {
               System.out.println("ql phieuthuedv ngaythue(): "+e.toString());
          }
          finally{
               try {
                     conn.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
          }  
        return pt;
      }
  public  static int getidkh()
  {
        int id= 0;
      Connection conn= null;
         PreparedStatement sttm= null;
          ResultSet rs=null;
          try {
              String sql ="select max(id) from phieu_thue";
            conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 rs=sttm.executeQuery();
              while(rs.next())
              {
                  id = rs.getInt(1)+1;   
              }          
          } catch (Exception e) {
               System.out.println("Error: "+e.toString());
          }
          finally{
               try {
                     conn.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
          }    
      return id;
  }
  // id khach hang theo so phong 
   public static int makh(String sophong)
      {
          Connection conn= null;
         PreparedStatement sttm= null;
          ResultSet rs=null;
          int id=0;
          try {
              String sql ="select max(id) from phieu_thue where sophong=?";
            conn=ketnoidb.getConnection();
                 sttm =conn.prepareStatement(sql);
                 sttm.setString(1, sophong);
                 rs=sttm.executeQuery();
              while(rs.next())
              {
                  id = rs.getInt(1);                  
              }          
          } catch (Exception e) {
               System.out.println("ql phieuthuedv makh() : "+e.toString());
          }
          finally{
               try {
                     conn.close();
                     sttm.close();
                 } catch (Exception e) {
                 }
          }    
        return id;
      }
}
