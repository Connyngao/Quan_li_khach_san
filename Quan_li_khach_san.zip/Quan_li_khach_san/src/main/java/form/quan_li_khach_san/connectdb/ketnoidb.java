/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.connectdb;

import java.beans.Statement;
import java.sql.*;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import javax.swing.JOptionPane;


/**
 *
 * @author user
 */
public class ketnoidb {
    private  static String url="jdbc:mysql://localhost:3306/qlks";
    private static String user ="root";
    private  static String password = "";
    public static Connection getConnection()
    {
        Connection cn = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            cn = DriverManager.getConnection(url, user, password);
          //
            System.out.println(cn.getCatalog());
        } catch (Exception ex) {
            System.out.println("Ket noi that bai.");
            ex.printStackTrace();
        }
        return cn;
    }
}


