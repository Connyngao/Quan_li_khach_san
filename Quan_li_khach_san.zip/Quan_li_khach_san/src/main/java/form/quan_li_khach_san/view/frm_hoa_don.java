/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package form.quan_li_khach_san.view;

import form.quan_li_khach_san.moder.dsphong;
import form.quan_li_khach_san.moder.hoadon;
import form.quan_li_khach_san.moder.login;
import form.quan_li_khach_san.moder.phieuthuedv;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import ql.dichvudao;
import ql.dsphongdao;
import ql.hoadondao;
import ql.phieuthuedao;
import ql.phieuthuedvdao;

/**
 *
 * @author user
 */
public class frm_hoa_don extends javax.swing.JFrame {
    hoadondao hddao= new hoadondao();
    /**
     * Creates new form frm_hoa_don
     */
  public frm_hoa_don() {
        initComponents();
        showhd();   
    }
  // set hóa đơn vào đối tượng hóa đơn
  public hoadon getmodel()
    {
//       if(hoadondao.makh(txt_sophong.getText())!=phieuthuedao.makh(txt_sophong.getText())) 
//       {    
        // lấy gia ngày hiện tại
       long millis=System.currentTimeMillis();  
       java.sql.Date date=new java.sql.Date(millis);
       float thanhtien;
       if(phieuthuedao.ngaythue(txt_sophong.getText())<=1)
       {
            thanhtien = dsphongdao.tienphong(txt_sophong.getText())+phieuthuedvdao.tiendv(txt_sophong.getText())
                   +Float.valueOf(txt_chiphikhac.getText());
       }
       else
       {
          thanhtien = dsphongdao.tienphong(txt_sophong.getText())*phieuthuedao.ngaythue(txt_sophong.getText())+phieuthuedvdao.tiendv(txt_sophong.getText())
                   +Float.valueOf(txt_chiphikhac.getText());  
       }
        
        hoadon hd = new hoadon();
        hd.setId(phieuthuedvdao.makh(txt_sophong.getText()));
        hd.setSophong(txt_sophong.getText());
        hd.setMaphieudv(phieuthuedvdao.maphieudv(txt_sophong.getText()));
        hd.setId_nv("");    // chưa thêm 
        hd.setNgaytra(date);
        hd.setChiphikhac(0+Integer.valueOf(txt_chiphikhac.getText()));
        hd.setThanhtoan(thanhtien);// khởi tạo hàm tính tiền theo số phòng và makh
        hd.setGhichu(txt_ghichu.getText());
       return hd;
       }
  // set  thông tin sửa hóa đơn
  //
  public hoadon getedithd()
  {
         float thanhtien;
       if(phieuthuedao.ngaythue(txt_sophong.getText())<=1)
       {
            thanhtien = dsphongdao.tienphong(txt_sophong.getText())+phieuthuedvdao.tiendv(txt_sophong.getText())
                   +Float.valueOf(txt_chiphikhac.getText());
       }
       else
       {
          thanhtien = dsphongdao.tienphong(txt_sophong.getText())*hoadondao.ngaythue(Integer.valueOf(lb_makh.getText()))+hoadondao.tiendv(Integer.valueOf(lb_makh.getText()))
                   +Float.valueOf(txt_chiphikhac.getText());  
       }
      hoadon hd = new hoadon();
      hd.setChiphikhac(Integer.valueOf(txt_chiphikhac.getText()));
      hd.setThanhtoan(thanhtien);
      hd.setGhichu(txt_ghichu.getText());
      hd.setId(Integer.valueOf(lb_makh.getText()));
      hd.setMahd(Integer.valueOf(lb_mahdd.getText()));
      return hd;
  }
   public  dsphong getmodelp()
    {
        dsphong p = new dsphong();   
        p.setTinhtrangphong("Sẵn sàng");
        p.setSophong(txt_sophong.getText());
        return p;
    }
  public void setmodel(hoadon hd)
  {
      lb_makh.setText(String.valueOf(hd.getId()));
      lb_mahdd.setText(String.valueOf(hd.getMahd()));
      txt_sophong.setText(hd.getSophong());
      lb_maphieudv.setText(hd.getMaphieudv());
      lb_manvv.setText(hd.getId_nv());
      lb_ngaytrap.setText(String.valueOf(hd.getNgaytra()));
      txt_chiphikhac.setText(String.valueOf(hd.getChiphikhac()+"đ"));
      lb_thanhtien.setText(String.valueOf(hd.getThanhtoan())+"đ");
      txt_ghichu.setText(hd.getGhichu());
      
      
  }
  //
  // show dv mà khách hàng đã sử dụng
  public void showpdv()
  {

        DefaultTableModel model = (DefaultTableModel) tb_dv.getModel();
      List<phieuthuedv> pdvlist = phieuthuedvdao.getpdvbyid(Integer.valueOf(lb_makh.getText()));
      model.setRowCount(0);
      for(phieuthuedv pdv:pdvlist)
      {
            Object data[]= new Object[5];
            data[0]=pdv.getMaphieudv();
            data[1]=pdv.getMadv();
            data[2]=pdv.getSoluong();
            data[3]=dichvudao.getgiadv(pdv.getMadv());
            data[4]=pdv.getThanhtien();
            model.addRow(data);
      }
  }
  // show bảng hóa đơn đã tạo
  public void showhd()
  {
      DefaultTableModel model = (DefaultTableModel) tb_hd.getModel();
      List<hoadon> hdlist = hoadondao.getallhd();
      model.setRowCount(0);
      for(hoadon hd:hdlist)
      {
            Object data[]= new Object[9];
            data[1]=hd.getId();
            data [0]=hd.getMahd();
            data[2]=hd.getSophong();
            data[3]=hd.getMaphieudv();
            data[4]=hd.getId_nv();
            data[5]=hd.getNgaytra();
            data[6]=hd.getChiphikhac();
            data[7] =hd.getThanhtoan();
            data[8] =hd.getGhichu();
            model.addRow(data);
      }
  }
   public boolean validateForm(){
        if( txt_sophong.getText().isEmpty()){
            return false;
        }
        return true;
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_ghichu = new javax.swing.JTextArea();
        txt_sophong = new javax.swing.JTextField();
        txt_chiphikhac = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lb_makh = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        btn_them = new javax.swing.JButton();
        btn_sua = new javax.swing.JButton();
        btn_reset = new javax.swing.JButton();
        lb_maphieudv = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lb_manvv = new javax.swing.JLabel();
        lb_mahdd = new javax.swing.JLabel();
        lb_ngaytrap = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lb_thanhtien = new javax.swing.JLabel();
        btn_thoat = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tb_dv = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        tb_hd = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(" "));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("Mã HD:");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("Số phòng :");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("Chi phí khác :");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("Ghi chú :");

        txt_ghichu.setColumns(20);
        txt_ghichu.setRows(5);
        jScrollPane1.setViewportView(txt_ghichu);

        txt_sophong.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_sophongActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Ngày trả phòng :");

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel9.setText("MaKH:");

        lb_makh.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lb_makh.setForeground(new java.awt.Color(0, 0, 255));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel11.setText("Ma phieuDV:");

        btn_them.setText("Tạo");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_sua.setText("Sửa");
        btn_sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_suaActionPerformed(evt);
            }
        });

        btn_reset.setText("reset");
        btn_reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_resetActionPerformed(evt);
            }
        });

        lb_maphieudv.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lb_maphieudv.setForeground(new java.awt.Color(0, 51, 255));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Mã NV:");

        lb_manvv.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lb_manvv.setForeground(new java.awt.Color(51, 51, 255));

        lb_mahdd.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lb_mahdd.setForeground(new java.awt.Color(51, 51, 255));

        lb_ngaytrap.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lb_ngaytrap.setForeground(new java.awt.Color(51, 51, 255));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel13.setText("Tổng tiền:");

        lb_thanhtien.setFont(new java.awt.Font("Times New Roman", 1, 12)); // NOI18N
        lb_thanhtien.setForeground(new java.awt.Color(51, 51, 255));

        btn_thoat.setText("Hủy");
        btn_thoat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_thoatActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(btn_them, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btn_sua, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(26, 26, 26)
                                .addComponent(btn_reset, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(btn_thoat, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lb_mahdd)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txt_chiphikhac, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
                                        .addComponent(txt_sophong))
                                    .addComponent(lb_manvv, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(41, 41, 41)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lb_ngaytrap, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lb_thanhtien, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(lb_makh, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addGap(25, 25, 25)
                                        .addComponent(lb_maphieudv, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_sophong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(lb_makh, javax.swing.GroupLayout.PREFERRED_SIZE, 9, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lb_maphieudv, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(lb_ngaytrap)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(txt_chiphikhac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(9, 9, 9)
                                .addComponent(jLabel2))
                            .addComponent(lb_mahdd, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(lb_manvv)
                            .addComponent(jLabel13)
                            .addComponent(lb_thanhtien))
                        .addGap(35, 35, 35)
                        .addComponent(jLabel5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btn_thoat, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addComponent(btn_sua, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                    .addComponent(btn_them, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btn_reset, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20))
        );

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Hóa Đơn");

        tb_dv.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Mã phieudv", "Mã dv", "Số lượng/Lần", "Giá dv", "Tổng tiền"
            }
        ));
        tb_dv.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_dvMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tb_dv);

        tb_hd.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã HD", "Mã KH", "Số phòng", "Mã Phiếu DV", "Mã nhân viên", "Ngày trả", "Chi phí khác", "Thanh toán", "Ghi chú"
            }
        ));
        tb_hd.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tb_hdMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tb_hd);

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel8.setText("Dịch vụ đã sử dụng");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(300, 300, 300)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 1006, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(118, 118, 118)
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1)
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(40, 40, 40)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 293, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tb_hdMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_hdMouseClicked
        // TODO add your handling code here:
        int id = tb_hd.getSelectedRow();
        String makh = tb_hd.getValueAt(id, 1).toString();
        setmodel(hoadondao.getkhByid(Integer.valueOf(makh)));
        showpdv();
    }//GEN-LAST:event_tb_hdMouseClicked

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        // TODO add your handling code here:
       if(validateForm()&&hoadondao.makh(txt_sophong.getText())!=phieuthuedao.makh(txt_sophong.getText()))
       {
           if(dsphongdao.gettp(txt_sophong.getText()).equalsIgnoreCase("Đang thuê"))
           {
       
           try
           {      hoadon hd= getmodel();
                if (hddao.add(hd)>0) {
                    dsphong phong = getmodelp();
                    dsphongdao.edittt(phong);
                    JOptionPane.showConfirmDialog(this, "Tạo thành công","thông báo",JOptionPane.YES_OPTION);
                    showhd();

                }
                else {JOptionPane.showConfirmDialog(this, "tạo thất bại");}

               }
           catch(Exception ex){
                Logger.getLogger(frm_hoa_don.class.getName()).log(Level.SEVERE, null, ex);
           }}
           else if(dsphongdao.gettp(txt_sophong.getText()).equalsIgnoreCase("Sẵng sàng"))
           {
              JOptionPane.showConfirmDialog(this, "phòng không thể tạo hóa đơn vì đang sẵng sàng"); 
           }
          
       }
       else {
                JOptionPane.showConfirmDialog(this, "Hóa đơn đã tồn tại hoặc nhập sai số phòng xin kiểm tra lại ","Erorr",JOptionPane.ERROR_MESSAGE);
             }
    }//GEN-LAST:event_btn_themActionPerformed

    private void tb_dvMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tb_dvMouseClicked
        // TODO add your handling code here:
        
    }//GEN-LAST:event_tb_dvMouseClicked

    private void txt_sophongActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_sophongActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txt_sophongActionPerformed

    private void btn_resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_resetActionPerformed
        // TODO add your handling code here:
        txt_sophong.setText("");
        txt_ghichu.setText("");
        txt_chiphikhac.setText("");
        lb_mahdd.setText("");
        lb_makh.setText("");
        lb_manvv.setText("");
        lb_ngaytrap.setText("");
        lb_thanhtien.setText("");
        lb_maphieudv.setText("");
    }//GEN-LAST:event_btn_resetActionPerformed

    private void btn_suaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_suaActionPerformed
        // TODO add your handling code here:
         if(validateForm())
       {
       
           try
           {      hoadon hd= getedithd();
                if (hddao.edit(hd)>0) {
                    JOptionPane.showConfirmDialog(this, "sửa thành công");
                    showhd();
                }
                else {JOptionPane.showConfirmDialog(this, "tạo thất bại","Erorr",JOptionPane.ERROR_MESSAGE);}
               }
           catch(Exception ex){
                Logger.getLogger(frm_hoa_don.class.getName()).log(Level.SEVERE, null, ex);
           }
          
       }
       else {
                JOptionPane.showConfirmDialog(this, "Nhập thông tin cần sửa: ","Erorr",JOptionPane.ERROR_MESSAGE);
             }
    }//GEN-LAST:event_btn_suaActionPerformed

    private void btn_thoatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_thoatActionPerformed
        // TODO add your handling code here:
        frm_thong_tin_phong frm = new frm_thong_tin_phong();
        frm.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btn_thoatActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frm_hoa_don.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frm_hoa_don.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frm_hoa_don.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frm_hoa_don.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frm_hoa_don().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_reset;
    private javax.swing.JButton btn_sua;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_thoat;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lb_mahdd;
    private javax.swing.JLabel lb_makh;
    private javax.swing.JLabel lb_manvv;
    private javax.swing.JLabel lb_maphieudv;
    private javax.swing.JLabel lb_ngaytrap;
    private javax.swing.JLabel lb_thanhtien;
    private javax.swing.JTable tb_dv;
    private javax.swing.JTable tb_hd;
    private javax.swing.JTextField txt_chiphikhac;
    private javax.swing.JTextArea txt_ghichu;
    private javax.swing.JTextField txt_sophong;
    // End of variables declaration//GEN-END:variables
}
