/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;

/**
 *
 * @author user
 */
public class thongtinphong {
    private String sophong,loaiphong;
    private int giaphong;
    private String tinhtrangphong;
    private int id;
    private String ghichu;

    public thongtinphong() {
    }

    public thongtinphong(String sophong, String loaiphong, int giaphong, String tinhtrangphong, int id, String ghichu) {
        this.sophong = sophong;
        this.loaiphong = loaiphong;
        this.giaphong = giaphong;
        this.tinhtrangphong = tinhtrangphong;
        this.id = id;
        this.ghichu = ghichu;
    }

    public String getSophong() {
        return sophong;
    }

    public void setSophong(String sophong) {
        this.sophong = sophong;
    }

    public String getLoaiphong() {
        return loaiphong;
    }

    public void setLoaiphong(String loaiphong) {
        this.loaiphong = loaiphong;
    }

    public int getGiaphong() {
        return giaphong;
    }

    public void setGiaphong(int giaphong) {
        this.giaphong = giaphong;
    }

    public String getTinhtrangphong() {
        return tinhtrangphong;
    }

    public void setTinhtrangphong(String tinhtrangphong) {
        this.tinhtrangphong = tinhtrangphong;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }
    
}
