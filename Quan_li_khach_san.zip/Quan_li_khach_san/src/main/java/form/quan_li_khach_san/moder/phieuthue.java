/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;

import java.sql.Date;


/**
 *
 * @author user
 */
public class phieuthue {
    private int id;
    private  String sophong,hodem,ten;
    private boolean gioitinh;
    private Date ngaysinh;
    private int ccd;
    private Date ngaythue;
    private String ghichu;
    public phieuthue() {
     
    }

    @Override
    public String toString() {
        return "phieuthue{" + "id=" + id + ", sophong=" + sophong + ", hodem=" + hodem + ", ten=" + ten + ", gioitinh=" + gioitinh + ", ngaysinh=" + ngaysinh + ", ccd=" + ccd + ", ngaythue=" + ngaythue + ", ghichu=" + ghichu + '}';
    }

    public phieuthue(String sophong, String hodem, String ten, boolean gioitinh, Date ngaysinh, int ccd, Date ngaythue, String ghichu) {
        this.sophong = sophong;
        this.hodem = hodem;
        this.ten = ten;
        this.gioitinh = gioitinh;
        this.ngaysinh = ngaysinh;
        this.ccd = ccd;
        this.ngaythue = ngaythue;
        this.ghichu = ghichu;
        
        
    }

   

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSophong() {
        return sophong;
    }

    public void setSophong(String sophong) {
        this.sophong = sophong;
    }

    public String getHodem() {
        return hodem;
    }

    public void setHodem(String hodem) {
        this.hodem = hodem;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public boolean isGioitinh() {
        return gioitinh;
    }

    public void setGioitinh(boolean gioitinh) {
        this.gioitinh = gioitinh;
    }

    public Date getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(Date ngaysinh) {
        this.ngaysinh = ngaysinh;
    }

    public int getCcd() {
        return ccd;
    }

    public void setCcd(int ccd) {
        this.ccd = ccd;
    }

    public Date getNgaythue() {
        return ngaythue;
    }

    public void setNgaythue(Date ngaythue) {
        this.ngaythue = ngaythue;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }
   
    
}

