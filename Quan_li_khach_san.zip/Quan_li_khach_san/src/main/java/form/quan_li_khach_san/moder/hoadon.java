/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;

import java.sql.Date;

/**
 *
 * @author user
 */
public class hoadon {
    private int id,mahd;
    private String sophong,maphieudv,id_nv;
    private Date ngaytra;
    private int chiphikhac;
    private float thanhtoan;
    private String ghichu;
    
    public hoadon() {
    }

    public hoadon(int id, int mahd, String sophong, String maphieudv, String id_nv, Date ngaytra, int chiphikhac, float thanhtoan, String ghichu) {
        this.id = id;
        this.mahd = mahd;
        this.sophong = sophong;
        this.maphieudv = maphieudv;
        this.id_nv = id_nv;
        this.ngaytra = ngaytra;
        this.chiphikhac = chiphikhac;
        this.thanhtoan = thanhtoan;
        this.ghichu = ghichu;
    }

    public hoadon(int id, String sophong, String maphieudv, String id_nv, Date ngaytra, int chiphikhac, int thanhtoan, String ghichu) {
        this.id = id;
        this.sophong = sophong;
        this.maphieudv = maphieudv;
        this.id_nv = id_nv;
        this.ngaytra = ngaytra;
        this.chiphikhac = chiphikhac;
        this.thanhtoan = thanhtoan;
        this.ghichu = ghichu;
    }

    @Override
    public String toString() {
        return "hoadon{" + "id=" + id + ", mahd=" + mahd + ", sophong=" + sophong + ", maphieudv=" + maphieudv + ", id_nv=" + id_nv + ", ngaytra=" + ngaytra + ", chiphikhac=" + chiphikhac + ", thanhtoan=" + thanhtoan + ", ghichu=" + ghichu + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMahd() {
        return mahd;
    }

    public void setMahd(int mahd) {
        this.mahd = mahd;
    }

    public String getSophong() {
        return sophong;
    }

    public void setSophong(String sophong) {
        this.sophong = sophong;
    }

    public String getMaphieudv() {
        return maphieudv;
    }

    public void setMaphieudv(String maphieudv) {
        this.maphieudv = maphieudv;
    }

    public String getId_nv() {
        return id_nv;
    }

    public void setId_nv(String id_nv) {
        this.id_nv = id_nv;
    }

    public Date getNgaytra() {
        return ngaytra;
    }

    public void setNgaytra(Date ngaytra) {
        this.ngaytra = ngaytra;
    }

    public int getChiphikhac() {
        return chiphikhac;
    }

    public void setChiphikhac(int chiphikhac) {
        this.chiphikhac = chiphikhac;
    }

    public float getThanhtoan() {
        return thanhtoan;
    }

    public void setThanhtoan(float thanhtoan) {
        this.thanhtoan = thanhtoan;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }
    
}
