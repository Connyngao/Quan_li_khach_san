/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;

import java.sql.Date;

/**
 *
 * @author user
 */
public class phieuthuephong { 
    
    private int idp;
    private String sophongString,maphieudvString;

    public phieuthuephong() {
    }

    public phieuthuephong(int idp, String sophongString) {
        this.idp = idp;
        this.sophongString = sophongString;
    }

    public phieuthuephong(String maphieudvString) {
        this.maphieudvString = maphieudvString;
    }

    public phieuthuephong(String sophongString, String maphieudvString) {
        this.sophongString = sophongString;
        this.maphieudvString = maphieudvString;
    }

    public int getIdp() {
        return idp;
    }

    public void setIdp(int idp) {
        this.idp = idp;
    }

    public String getSophongString() {
        return sophongString;
    }

    public void setSophongString(String sophongString) {
        this.sophongString = sophongString;
    }

    public String getMaphieudvString() {
        return maphieudvString;
    }

    public void setMaphieudvString(String maphieudvString) {
        this.maphieudvString = maphieudvString;
    }

    @Override
    public String toString() {
        return "phieuthuephong{" + "idp=" + idp + ", sophongString=" + sophongString + ", maphieudvString=" + maphieudvString + '}';
    }
   

   
}
