/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;

import java.sql.Date;

/**
 *
 * @author user
 */
public class nhanvien {
    private String id;
    private String hodem,ten;
    private boolean gioitinh;
    private Date ngaysinh;
    private String sdt;
    private int cccd;
    private String chucvu,diachi;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public nhanvien() {
    }

    public nhanvien(String hodem, String ten, boolean gioitinh, Date ngaysinh, String sdt, int cccd, String chucvu, String diachi) {
        this.hodem = hodem;
        this.ten = ten;
        this.gioitinh = gioitinh;
        this.ngaysinh = ngaysinh;
        this.sdt = sdt;
        this.cccd = cccd;
        this.chucvu = chucvu;
        this.diachi = diachi;
    }

    public nhanvien(String id, String hodem, String ten, boolean gioitinh, Date ngaysinh, String sdt, int cccd, String chucvu, String diachi) {
        this.id = id;
        this.hodem = hodem;
        this.ten = ten;
        this.gioitinh = gioitinh;
        this.ngaysinh = ngaysinh;
        this.sdt = sdt;
        this.cccd = cccd;
        this.chucvu = chucvu;
        this.diachi = diachi;
    }

    

    public String getHodem() {
        return hodem;
    }

    public void setHodem(String hodem) {
        this.hodem = hodem;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public boolean isGioitinh() {
  
        return gioitinh;
    }
    

    public void setGioitinh(boolean gioitinh) {
        this.gioitinh = gioitinh;
    }

    public Date getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(Date ngaysinh) {
        this.ngaysinh = ngaysinh;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public int getCccd() {
        return cccd;
    }

    public void setCccd(int cccd) {
        this.cccd = cccd;
    }

    public String getChucvu() {
        return chucvu;
    }

    public void setChucvu(String chucvu) {
        this.chucvu = chucvu;
    }

    public String getDiachi() {
        return diachi;
    }

    public void setDiachi(String diachi) {
        this.diachi = diachi;
    }
  
}
