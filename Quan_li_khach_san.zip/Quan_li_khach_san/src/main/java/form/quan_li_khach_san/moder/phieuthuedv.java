/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;

/**
 *
 * @author user
 */
public class phieuthuedv {
    private String maphieudv;
    private int id;
    private String madv;
    private int soluong,thanhtien;
    private String ghichu;
    public String sophong;

    public String getSophong() {
        return sophong;
    }

    public void setSophong(String sophong) {
        this.sophong = sophong;
    }
    public phieuthuedv() {
    }

    
    public phieuthuedv(String maphieudv, int id, String madv, int soluong, int thanhtien, String ghichu) {
        this.maphieudv = maphieudv;
        this.id = id;
        this.madv = madv;
        this.soluong = soluong;
        this.thanhtien = thanhtien;
        this.ghichu = ghichu;
    }

    @Override
    public String toString() {
        return "phieuthuedv{" + "maphieudv=" + maphieudv + ", sophong=" + id + ", madv=" + madv + ", soluong=" + soluong + ", thanhtien=" + thanhtien + ", ghichu=" + ghichu + '}';
    }

    public String getMaphieudv() {
        return maphieudv;
    }

    public void setMaphieudv(String maphieudv) {
        this.maphieudv = maphieudv;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMadv() {
        return madv;
    }

    public void setMadv(String madv) {
        this.madv = madv;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public int getThanhtien() {
        return thanhtien;
    }

    public void setThanhtien(int thanhtien) {
        this.thanhtien = thanhtien;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }
    
}
