/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;

/**
 *
 * @author user
 */
public class login {
    private int id;
    private String users,password,manv;

    @Override
    public String toString() {
        return "User{" + "id=" + id + ", users=" + users + ", password=" + password + ", chucvu=" + manv + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsers() {
        return users;
    }

    public void setUsers(String users) {
        this.users = users;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getManv() {
        return manv;
    }

    public void setManv(String chucvu) {
        this.manv = chucvu;
    }
    
}
