/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;


import java.sql.Date;


/**
 *
 * @author user
 */
public  class  khachhang {

    static int getid() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    private int id;
    private String hodem,ten;
    private boolean gioitinh;
    private Date ngaysinh;
    private int cccd;
   // private int solan;

//    public int getSolan() {
//        return solan;
//    }
//
//    public void setSolan(int solan) {
//        this.solan = solan;
//    }

    public khachhang(String hodem, String ten, boolean gioitinh, Date ngaysinh, int cccd) {
        
        this.hodem = hodem;
        this.ten = ten;
        this.gioitinh = gioitinh;
        this.ngaysinh = ngaysinh;
        this.cccd = cccd;
       // this.solan = solan;
    }


    public khachhang() {
    }
    
    public khachhang(int id, String hodem, String ten, boolean gioitinh, Date ngaysinh, int cccd) {
        this.id = id;
        this.hodem = hodem;
        this.ten = ten;
        this.gioitinh = gioitinh;
        this.ngaysinh = ngaysinh;
        this.cccd = cccd;
        
    }


    @Override
    public  String toString() {
        
        return "khachhang{" + "id=" + id + ", hodem=" + hodem + ", ten=" + ten + ", gioitinh=" + gioitinh + ", ngaysinh=" + ngaysinh + ", cccd=" + cccd + "," +
                '}' ;
    }

    public String getHodem() {
        return hodem;
    }

    public void setHodem(String hodem) {
        this.hodem = hodem;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public boolean isGioitinh() {
       
        return gioitinh;
    }

    public void setGioitinh(boolean gioitinh) {
      this.gioitinh=gioitinh;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



    public int getCccd() {
        return cccd;
    }

    public void setCccd(int cccd) {
        this.cccd = cccd;
    }

    public Date getNgaysinh() {
        return ngaysinh;
    }

    public void setNgaysinh(Date ngaysinh) {
        this.ngaysinh = ngaysinh;
    }
    
    
}
