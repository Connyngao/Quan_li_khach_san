/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package form.quan_li_khach_san.moder;

/**
 *
 * @author user
 */
public class dichvu {
    private String madv,tendv;
    private int giadv,soluong;
    private String loaidv,tinhtrang,ghichu;

    public dichvu(String madv, String tendv, int giadv, String loaidv, String tinhtrang, String ghichu) {
        this.madv = madv;
        this.tendv = tendv;
        this.giadv = giadv;
        this.loaidv = loaidv;
        this.tinhtrang = tinhtrang;
        this.ghichu = ghichu;
    }

    public int getSoluong() {
        return soluong;
    }

    public void setSoluong(int soluong) {
        this.soluong = soluong;
    }

    public dichvu(String madv, String tendv, int giadv, int soluong, String loaidv, String tinhtrang, String ghichu) {
        this.madv = madv;
        this.tendv = tendv;
        this.giadv = giadv;
        this.soluong = soluong;
        this.loaidv = loaidv;
        this.tinhtrang = tinhtrang;
        this.ghichu = ghichu;
    }

    public dichvu() {
    }

    @Override
    public String toString() {
        return "dichvu{" + "madv=" + madv + ", tendv=" + tendv + ", giadv=" + giadv + ", soluong=" + soluong + ", loaidv=" + loaidv + ", tinhtrang=" + tinhtrang + ", ghichu=" + ghichu + '}';
    }

    

    public String getMadv() {
        return madv;
    }

    public void setMadv(String madv) {
        this.madv = madv;
    }

    public String getTendv() {
        return tendv;
    }

    public void setTendv(String tendv) {
        this.tendv = tendv;
    }

    public int getGiadv() {
        return giadv;
    }

    public void setGiadv(int giadv) {
        this.giadv = giadv;
    }

    public String getLoaidv() {
        return loaidv;
    }

    public void setLoaidv(String loaidv) {
        this.loaidv = loaidv;
    }

    public String getTinhtrang() {
        return tinhtrang;
    }

    public void setTinhtrang(String tinhtrang) {
        this.tinhtrang = tinhtrang;
    }

    public String getGhichu() {
        return ghichu;
    }

    public void setGhichu(String ghichu) {
        this.ghichu = ghichu;
    }
        
}
